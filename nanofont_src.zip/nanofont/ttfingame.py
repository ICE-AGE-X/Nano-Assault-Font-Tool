from PIL import Image, ImageDraw, ImageFont
import libs
font_w = 16
tex_w = 512
tex_h = 512
start_char_code = 0x819e
font = ImageFont.truetype('end.ttf', font_w)
image = Image.open("ingame_temp.png")
# image = Image.new(mode='RGBA', size=(tex_w, tex_h))
draw_table = ImageDraw.Draw(im=image)
idx = start_char_code
next_limt = 0x8200
y = 84

charMapF = open("charmap.txt", "r", encoding="utf-16")
chars = []
while(True):
    text = charMapF.readline()
    if(text):
        text.replace("\n", "")
        chars.append(text.split('=')[1].replace("\n", ""))
    else:
        break
charMapF.close()
# print(chars)
# exit(0)
f3d = open("ingame.f3d", 'wb')
# libs.writeInt1(f3d, 5)
# libs.writeInt1(f3d, font_w)
# libs.writeInt1(f3d, font_w)
# libs.writeInt1(f3d, 0)
libs.writeInt2(f3d, idx)
libs.writeInt2(f3d, next_limt)
char_idx = 0
x = 1
# count = 0
is_first = True
while(y < tex_h-font_w):
    if(is_first):
        x = 1
        is_first = False
    else:
        x = 1
    if(char_idx >= len(chars)):
        break
    while(x < tex_w):
        if(char_idx >= len(chars)):
            break
        size = font.getsize(chars[char_idx])
        if(x+size[0] > tex_w):
            break
        libs.writeInt2(f3d, x)
        libs.writeInt2(f3d, y)
        libs.writeInt1(f3d, size[0])
        libs.writeInt1(f3d, font_w)
        draw_table.text(xy=(
            x, y), spacing=0, text=chars[char_idx], fill='#ffffff', font=font, align="center")
        x = x+size[0]+1
        idx += 1
        char_idx += 1
        if(idx >= next_limt):
            libs.writeInt2(f3d, idx)
            next_limt += 0x100
            if(next_limt > start_char_code+len(chars)):
                libs.writeInt2(f3d, start_char_code+len(chars))
            else:
                libs.writeInt2(f3d, next_limt)

    y = y+font_w+1
libs.writeInt2(f3d, 0)
libs.writeInt2(f3d, 0)
f3d.close()
# print(ary)
image.save('ingame.png', 'PNG')
image.close()
